package com.example.ecommerce_cart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
